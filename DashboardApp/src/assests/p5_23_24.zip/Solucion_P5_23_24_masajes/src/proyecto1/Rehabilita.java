/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto1;

import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author pedro
 */
public class Rehabilita implements Runnable {

    private Centro t;
    private CanvasCentro cv;

    public Rehabilita(Centro tl, CanvasCentro cv) {
        t = tl;
        this.cv=cv;
    }

    @Override
    public void run() {
        Random rnd = new Random();
        rnd.setSeed(System.currentTimeMillis());
        try {

            int id=(int) Thread.currentThread().getId();
            //System.out.println("Soy furgo " + Thread.currentThread().getName());
            cv.inserta('R', id);
            t.entraRehabilita();
            cv.quita('R', id);
            //System.out.println("                                    ----> furgo " + Thread.currentThread().getName() + " ATENDIDO POR " + donde);
            cv.rehabilita('R', id);
            Thread.sleep((rnd.nextInt(3) + 1) * 2000);
            //System.out.println("                                       <---- FIN furgo " + Thread.currentThread().getName());
            cv.finalizado('R', id);
            t.saleRehabilita();
            cv.finalizadoquitar('R', id);
            cv.vestuario(id,'R');
            Thread.sleep(3000);
            cv.vestuario(0,'R');
            t.termina();


        } catch (InterruptedException ex) {
            Logger.getLogger(Masaje.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
