/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto1;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.MediaTracker;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.awt.image.ColorModel;
import java.util.ArrayList;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author pedro
 */
public class CanvasCentro extends Canvas {

    private class encola {

        private int id;
        private char tipo;

        public encola(int elid, char eltipo) {
            this.id = elid;
            this.tipo = eltipo;
        }

        public int getId() {
            return id;
        }

        public char getTipo() {
            return tipo;
        }

        public void setId(int id) {
            this.id = id;
        }

        public void setTipo(char tipo) {
            this.tipo = tipo;
        }

        @Override
        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (obj == null) {
                return false;
            }
            if (getClass() != obj.getClass()) {
                return false;
            }
            final encola c = (encola) obj;
            if (c.getId() == this.getId()) {
                return true;
            } else {
                return false;
            }
        }

    }

    private final ArrayList<encola> colamasaje = new ArrayList();
    private final ArrayList<encola> colarehabilita = new ArrayList();
    private final MediaTracker dibu;
    Image compradorimg, repararimg, empleadoA, empleadoB;
    private final Random rnd = new Random(System.currentTimeMillis());
    encola masajista, fisio, masajistafin, fisiofin;
    private int envesturario = 0;
    private char tipovestuario = 'N';

    /**
     *
     * @param ancho del frame
     * @param alto del frame
     * @throws InterruptedException
     */
    public CanvasCentro(int ancho, int alto) throws InterruptedException {

        setSize(ancho, alto);
        setBackground(Color.white);

        compradorimg = Toolkit.getDefaultToolkit().getImage(getClass().getResource("image/espera2.jpg"));
        repararimg = Toolkit.getDefaultToolkit().getImage(getClass().getResource("image/espera3.jpg"));
        empleadoA = Toolkit.getDefaultToolkit().getImage(getClass().getResource("image/masaje1.png"));
        empleadoB = Toolkit.getDefaultToolkit().getImage(getClass().getResource("image/masaje2.png"));

        dibu = new MediaTracker(this);
        dibu.addImage(compradorimg, 1);
        dibu.waitForID(1);
        dibu.addImage(repararimg, 2);
        dibu.waitForID(2);
        dibu.addImage(empleadoA, 3);
        dibu.waitForID(3);
        dibu.addImage(empleadoB, 4);
        dibu.waitForID(4);

        masajista = null;
        fisio = null;

    }

    /**
     * Inserta el id en la cola indicada.
     *
     * @param donde puede ser 'M' para la cola de "masaje" o 'R' paera la cola
     * de reparación
     * @param id que se inserta en la cola
     */
    public synchronized void inserta(char donde, int id) {
        encola nuevo = new encola(id, donde);
        if (donde == 'M') {
            colamasaje.add(nuevo);
        } else {
            colarehabilita.add(nuevo);
        }
        this.repaint();
    }

    /**
     * Elimina el id de la cola indicada
     *
     * @param donde puede ser 'M' para la cola de "masaje" o 'R' paera la cola
     * de reparación
     * @param id que se inserta en la cola
     */
    public synchronized void quita(char donde, int id) {
        ArrayList<encola> cola;
        if (donde == 'M') {
            cola = colamasaje;
        } else {
            cola = colarehabilita;
        }
        encola c = new encola(id, donde);
        cola.remove(c);

        this.repaint();

    }

    /**
     * Pone a Comprar el id que se pasa
     *
     * @param en_cual Si es 'V' lo coloca con el masajista y si es 'M' lo coloca
     * con el mecánico
     * @param id que se visualizará en el sitio
     */
    public synchronized void rehabilita(char en_cual, int id) {
        if (en_cual == 'M') {
            masajista = new encola(id, 'R');
        } else {
            fisio = new encola(id, 'R');
        }

        this.repaint();
    }

    /**
     * Pone a reparar el id que se pasa
     *
     * @param en_cual Si es 'V' lo coloca con el masajista y si es 'M' lo coloca
     * con el mecánico
     * @param id que se visualizará en el sitio
     */
    public synchronized void masaje(char en_cual, int id) {
        if (en_cual == 'M') {
            masajista = new encola(id, 'M');
        } else {
            fisio = new encola(id, 'M');
        }

        this.repaint();
    }

    public synchronized void vestuario(int id, char tipo) {
        envesturario = id;
        tipovestuario = tipo;
    }

    /**
     * Quita de comprar o reparar el id que se pasa
     *
     * @param en_cual Si es 'V' lo quita del masajista y si es 'M' lo quita del
     * fisio
     * @param id
     */
    public synchronized void finalizado(char en_cual, int id) {
        if (en_cual == 'M') {
            masajistafin = masajista;
            masajista = null;
        } else {
            fisiofin = fisio;
            fisio = null;
        }
        repaint();

    }

    public synchronized void finalizadoquitar(char en_cual, int id) {
        if (en_cual == 'M') {
            masajistafin = null;
        } else {
            fisiofin = null;
        }
        repaint();

    }

    @Override
    public void update(Graphics g) {
        paint(g);
    }

    @Override
    public synchronized void paint(Graphics g) {
        BufferedImage imagen = new BufferedImage(getWidth(), getHeight(), ColorModel.OPAQUE);
        Font f1 = new Font("Arial", Font.BOLD, 12);
        Font f2 = new Font("Sans", Font.BOLD, 20);
        Graphics gbuf = imagen.getGraphics();
        gbuf.setColor(Color.GRAY);
        gbuf.fillRect(0, 0, getWidth(), getHeight());
        gbuf.setFont(f1);

        //RECTANGULO DE LA COLA DE MASAJES
        gbuf.setColor(Color.white);
        gbuf.fillRect(40, 20, getWidth() - 180, 100);
        gbuf.drawString("Cola de Masajes", 40, 15);

        //RECTANGULO DE LA SALA DE FISIO
        gbuf.setColor(Color.white);
        gbuf.fillRect(40, 140, (getWidth() - 200) / 2, 250);
        gbuf.setFont(f2);
        gbuf.setColor(Color.BLUE);
        gbuf.drawString("FISIOTERAPEUTA", 140, 200);
        gbuf.drawImage(empleadoA, 160, 220, null);

        //RECTANGULO DE LA SALA DE MASAJES
        gbuf.setColor(Color.white);
        gbuf.fillRect((getWidth() - 100) / 2 + 10, 140, (getWidth() - 200) / 2, 250);
        gbuf.setColor(Color.RED);
        gbuf.drawString("MASAJISTA", (getWidth() - 100) / 2 + 130, 200);
        gbuf.drawImage(empleadoB, 525, 220, null);

        //RECTANGULO DE LA COLA DE REHABILITAION        
        gbuf.setFont(f1);
        gbuf.setColor(Color.white);
        gbuf.fillRect(40, 420, getWidth() - 180, 100);
        gbuf.drawString("Cola de Rehabilitación", 40, 415);

        //RECTANGULO DEL VESTUARIO
        gbuf.setColor(Color.white);
        gbuf.fillRect(getWidth() - 110, 140, 90, 250);
        gbuf.setColor(Color.BLACK);
        gbuf.drawString("VESTUARIO", getWidth() - 100, 200);

        gbuf.setColor(Color.black);

        for (int i = 0; i < colamasaje.size(); i++) {            
            encola e = colamasaje.get(i);
            gbuf.drawString("     " + e.getId() + "   ", 60 + 70 * i, 40);
            gbuf.drawImage(compradorimg, 60 + 70 * i, 40, null);
        }

      
        for (int i = 0; i < colarehabilita.size(); i++) {
            
            encola e = colarehabilita.get(i);
            gbuf.drawString("     " + e.getId() + "   ", 60 + 70 * i, 440);
            gbuf.drawImage(repararimg, 60 + 70 * i, 440, null);
        }

        if (fisio != null) {
            if (fisio.getTipo() == 'M') {
                gbuf.drawString("     " + fisio.getId() + "   ", 60, 230);
                gbuf.drawImage(compradorimg, 60, 230, null);
            } else {
                gbuf.drawString("     " + fisio.getId() + "   ", 60, 230);
                gbuf.drawImage(repararimg, 60, 230, null);
            }
        }

        if (fisiofin != null) {
            if (fisiofin.getTipo() == 'M') {
                gbuf.drawString("     " + fisiofin.getId() + "   ", 300, 230);
                gbuf.drawImage(compradorimg, 300, 230, null);
            } else {
                gbuf.drawString("     " + fisiofin.getId() + "   ", 300, 230);
                gbuf.drawImage(repararimg, 300, 230, null);
            }
        }

        if (masajista != null) {
            if (masajista.getTipo() == 'M') {
                gbuf.drawString("     " + masajista.getId() + "   ", 450, 230);
                gbuf.drawImage(compradorimg, 450, 230, null);
            } else {
                gbuf.drawString("     " + masajista.getId() + "   ", 450, 230);
                gbuf.drawImage(repararimg, 450, 230, null);
            }
        }

        if (masajistafin != null) {
            if (masajistafin.getTipo() == 'M') {
                gbuf.drawString("     " + masajistafin.getId() + "   ", 650, 230);
                gbuf.drawImage(compradorimg, 650, 230, null);
            } else {
                gbuf.drawString("     " + masajistafin.getId() + "   ", 650, 230);
                gbuf.drawImage(repararimg, 650, 230, null);
            }
        }
        if (envesturario != 0) {
            if (tipovestuario == 'M') {
                gbuf.drawString("     " + envesturario + "   ", 830, 230);
                gbuf.drawImage(compradorimg, 830, 230, null);
            } else {
                gbuf.drawString("     " + envesturario + "   ", 830, 230);
                gbuf.drawImage(repararimg, 830, 230, null);
            }
        }

        g.drawImage(imagen, 0, 0, this);
        try {
            Thread.sleep(10);
        } catch (InterruptedException ex) {
            Logger.getLogger(CanvasCentro.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
}
