/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto1;

/**
 *
 * @author pedro
 */
public class Centro {

    private volatile int librefixio = 1, libremasaje = 1, librevestuario = 1, esperafixio = 0;

    public synchronized char entraMasaje() throws InterruptedException {

        while (libremasaje == 0 && ((librefixio == 0) || (esperafixio > 0))) {
            wait();
        }
        if (libremasaje > 0) {
            libremasaje--;
            return 'M';
        } else {
            librefixio--;
            return 'R';
        }
    }

    public synchronized void saleMasaje(char quien) throws InterruptedException {
        while (librevestuario == 0) {
            wait();
        }
        librevestuario--;
        if (quien == 'M') {
            libremasaje++;
        } else {
            librefixio++;
        }
        notifyAll();
    }

    public synchronized void entraRehabilita() throws InterruptedException {
        esperafixio++;
        while ((librefixio == 0)) {
            wait();
        }
        esperafixio--;
        librefixio--;

    }

    public synchronized void saleRehabilita() throws InterruptedException {
        while (librevestuario == 0) {
            wait();
        }
        librevestuario--;
        librefixio++;
        notifyAll();
    }

    public synchronized void termina() {
        librevestuario++;
        notifyAll();
    }
}
