/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto1;

import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author pedro
 */
public class Masaje extends Thread {

    private Centro t;
    private CanvasCentro cv;

    public Masaje(Centro tl, CanvasCentro cv) {
        t = tl;
        this.cv=cv;
    }

    @Override
    public void run() {
        Random rnd = new Random();
        rnd.setSeed(System.currentTimeMillis());
        try {
            int id=(int) Thread.currentThread().getId();
            //System.out.println("Soy el coche "+getName());
            cv.inserta('M',id);
            char quien=t.entraMasaje();
            cv.quita('M', id);
            cv.masaje(quien, id);
            //System.out.println("                 ----> coche "+getName()+" ATENDIDO en "+donde);
            Thread.sleep((rnd.nextInt(3) + 1) * 2000);
            //System.out.println("                 <---- FIN coche "+getName());
            cv.finalizado(quien, id);
            t.saleMasaje(quien);
            cv.finalizadoquitar(quien, id);
            cv.vestuario(id,'M');
            Thread.sleep(3000);
            cv.vestuario(0,'M');
            t.termina();

        } catch (InterruptedException ex) {
            Logger.getLogger(Masaje.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}
